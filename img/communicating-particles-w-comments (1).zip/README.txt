A Pen created at CodePen.io. You can find this one at http://codepen.io/torahlee/pen/jrpZqw.

 Object Oriented Goo.
LC - add points
RC - remove points
